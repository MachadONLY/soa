package com.faculdade.vicioapostas.model;

public enum TipoSessao {
    CONSULTA_INICIAL,
    ACOMPANHAMENTO,
    EMERGENCIA,
    GRUPO_APOIO
}

