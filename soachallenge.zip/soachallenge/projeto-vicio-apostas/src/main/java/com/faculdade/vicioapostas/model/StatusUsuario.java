package com.faculdade.vicioapostas.model;

public enum StatusUsuario {
    ATIVO,
    INATIVO,
    EM_TRATAMENTO
}

