package com.faculdade.vicioapostas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VicioApostasApplicationTests {

    @Test
    void contextLoads() {
        // Teste básico para verificar se o contexto do Spring carrega corretamente
    }

}

