# Integrantes - Turma 3ESR

## João Morais --> RM55043
## Juliana Maita --> RM99224
## Luana Cabezaolias --> RM99320
## Lucca Vilaça --> RM551538
## Pedro Farath --> RM98608
